﻿namespace Kalitim
{
    class Arac
    {
        public string Renk { get; set; }
        public int Hiz { get; set; }
        public void Ivmelenme()
        {
            Console.WriteLine("İvmeleniyor");
        }

        public void Frenleme()
        {
            Console.WriteLine("Frenleniyor");
        }
    }
    class Araba : Arac
    {
        public int KapiSayisi { get; set; }
        public string Marka { get; set; }
        public string YakitTipi { get; set; }

    }

    class SporAraba : Araba
    {
        public bool Turbo { get; set; }
        public float MaksimumHiz { get; set; }
    }

    class Bilgisayar
    {
        public string Islemci { get; set; }
        public Bilgisayar(string isim)
        {

        }

        public Bilgisayar(int tip)
        {

        }


    }

    class Laptop : Bilgisayar
    {
        public string Batarya { get; set; }
        public string Touchpad { get; set; }
        public Laptop() : base("isim")
        {
            Console.WriteLine("Laptop üretildi");
        }
    }

    class Bitki
    {
        public int deneme;
        public string Boy { get; set; }
    }
    class A : Object
    {

    }

    class B : A
    {


    }

    class C : B
    {

    }




    internal class Program
    {

        static void Main(string[] args)
        {
            Arac arac1 = new Arac();
            arac1.Hiz = 120;
            arac1.Renk = "Siyah";
            Arac arac2 = new Arac();
            arac1.Hiz = 240;
            arac1.Renk = "Kirmizi";
            Araba araba1 = new Araba();
            araba1.Marka = "Mercedes";
            araba1.Hiz = 250;
            araba1.Renk = "Beyaz";

            var a = 5;
            dynamic b = 7;
            object c = 2.7;

            Laptop laptop1 = new Laptop();
            Bitki bitki1 = new Bitki();
        }
    }
}
