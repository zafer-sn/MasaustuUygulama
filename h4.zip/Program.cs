﻿using System.Net.WebSockets;

internal class Program
{
    private static void Main(string[] args)
    {
        #region Switch-Case Ornek1
        int deger1 = 25;
        switch (deger1)
        {
            case 20:
                Console.WriteLine("Merhaba");
                break;
            case 30:
                Console.WriteLine("Selam");
                break;
            case 25:
                Console.WriteLine("Zafer");
                break;
            case 75:
                Console.WriteLine("Deneme");
                break;
            default:
                Console.WriteLine("Hiçbirine uymuyor");
                break;
        }
        #endregion
        #region Switch-Case Ornek2
        int deger2 = 25;
        switch (75)
        {
            case 20:
                Console.WriteLine("Merhaba");
                break;
            case 30:
                Console.WriteLine("Selam");
                break;
            default:
                Console.WriteLine("Hiçbirine uymuyor");
                break;
            case 25:
                Console.WriteLine("Zafer");
                break;
            case 75:
                Console.WriteLine("Deneme");
                break;
        }
        #endregion
        #region Switch-Case Ornek3
        var deger3 = "slm";
        var deger4 = 25;
        switch (deger3)
        {
            case "mrb":
                Console.WriteLine(5 + 3);
                break;
            case "slm" when (deger4 > 5):
                Console.WriteLine(Convert.ToInt32(false) * 5);
                break;
        }
        #endregion
        #region if yapılanması örnek 1
        char deger5 = '*';
        if (deger5 != 'z') // = atama(assign) operatörü == matematiksel eşittir
        {
            Console.WriteLine("if çalışır");
        }
        #endregion
        #region if yapılanması örnek 2
        #endregion
        object deger6 = 5.4;
        Console.WriteLine("nasılsın");
        if ((double)deger6 <= 5.3) // 5.4 <= 5.3 - false
        {
            Console.WriteLine("değer 6 -- 5.3'ten küçüktür");

        }
        else
        {
            Console.WriteLine("değer 6 -- 5.3'ten büyüktür");
        }
        #region if yapılanması örnek 2
        var deger7 = 115;
        var deger8 = "test";
        if (deger7 == 115 && false)
        {
            Console.WriteLine(deger7);
        }
        else if (deger7 == 125 && false)
        {
            Console.WriteLine("selam");
        }
        else if (deger7 == 255 || deger8 == "tttest")
        {
            Console.WriteLine("görüşürüz");
        }
        else
        {
            Console.WriteLine("deneme");
        }

        #endregion
        #region Type Pattern
        object deger9 = 11;
        if (deger9 is int _deger9)
        {
            Console.WriteLine(_deger9 + _deger9);
        }
        #endregion
        #region Constant Pattern
        object deger10 = 230;
        if (deger10 is 230) // deger10 == 230
        {
            // Console.WriteLine(deger10 + deger10);
            Console.WriteLine("MERHABA");
        }
        #endregion
        #region for döngüsü
        for (int i = 0; i < 15; i = i + 7)
        {
            Console.WriteLine(i);
        }
        #endregion
        #region while döngüsü
        var sayi = 0;
        while (sayi < 15)
        {
            sayi = sayi + 7;

            Console.WriteLine(sayi);
        }
        #endregion
        #region do while döngüsü
        var sayi_ = 0;
        do
        {
            Console.WriteLine(sayi_);
            sayi_++;
        } while (sayi_ > 255);
        #endregion
        #region for döngüsü örnek
        for (int i = 0; i < 101; i++)
        {
            Console.WriteLine(i);
            if (i == 45)
            {
                break;
            }
            Console.WriteLine("selam");

        }

        #endregion
        #region for döngüsü continue
        for (int i = 0; i < 55; i++)
        {
            if (i % 2 == 0)
            {
                continue;
            }
            Console.WriteLine(i);
        }
        #endregion
        #region diziler
        int[] isimler = new int[5];
        isimler[3] = 21;
        isimler[0] = 555;

        try
        { Console.WriteLine(isimler[55]); }
        catch (IndexOutOfRangeException ex)
        {
            Console.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        foreach (var item in isimler)
        {
            Console.WriteLine(item);
        }

        int[] sayilar = { 1, 2, 3, 11, 25 };
        int[] sayilar2 = new int[3] { 1, 5, 7 };
        int[] sayilar3 = new int[] { 1, 5 };
        #endregion
    }
}