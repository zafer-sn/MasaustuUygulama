﻿internal class Program
{
    private static void Main(string[] args)
    {
        // Tek satırlık yorum
        /*
         Çok satırlık
         yorum
         */
        #region Burada örnek bir döngü vardır.
        for (int i = 0; i < 100; i++)
        {
            Console.WriteLine("Selam");
        }
        #endregion

        #region Burada konsola Servis yazdırıldı
        Console.WriteLine("Servis");
        #endregion

        //todo yorum satırı başına todo eklenerek task listte kontrol sağlanabilir
        for (int i = 0; i < 1000; i++)
        {
            if(i % 2 == 0)
            {
                Console.WriteLine(i);
            }
        }
        /*
         Kural-1: Değişken isimleri sayı ile başlayamaz.
         Kural-2: Değişken isimlerinde özel karakter kullanılamaz.(_ hariç)
         Kural-3: Değişken isimlerinde Türkçe karakter kullanmıyoruz.(ö, ç, ü, ğ, ş)
         Kural-4: c# büyük-küçük harf duyarlıdır.
         Kural-5: c#'ta kullanılan built-in tipler değişken adı olarak normal şartlarda verilemez.(@ kullanımı hariç)
        */
        int sayi1 = 5;
        float sayi2 = 5.7f;
        decimal sayi3 = 5.4m;
        string isim = "zafer";
        char aKarakteri = 'a';
        bool girisYapildimi = true;
        int sayi4;
        sayi4 = 11;
        int sayi5;
        //Console.WriteLine(sayi5);
        /*
         Değişken adı verirken şu yapılarda kullanım önerilir:
         camelCase : int birinciSayininDegeri;
         PascalCase: int BirinciSayininDegeri;
         snake_case: int birinci_sayinin_degeri;
         */
        
        //todo Buradan sonrasını öğrenci yapacak.        
    }
}