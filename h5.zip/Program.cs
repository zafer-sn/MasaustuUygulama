﻿namespace hafta5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Selamla();
            // Selamla2(yas: 35, isim: "Ahmet"); // Selamla2("Zafer", 25);
            // int donus_degeri = Selamla3();
            // Console.WriteLine(donus_degeri * 2);
            // int donus_degeri2 = Selamla4(18, 12);
            // Console.WriteLine(donus_degeri2);

            Ogrenci ogrenci1 = new Ogrenci();
            Console.WriteLine(ogrenci1.Topla(25, 11));
            /*ogrenci1.isim = "Yusuf";
            ogrenci1.yas = 20;
            ogrenci1.cinsiyet = true;
            ogrenci1.boy = 1.70;
            ogrenci1.kilo = 80;
            ogrenci1.numara = 15;*/
            ogrenci1.Bakiye = 250;
            Console.WriteLine(ogrenci1.Bakiye);
            ogrenci1.Para = 2500;
            Console.WriteLine(ogrenci1.Para);
            ogrenci1[2] = 25;
            Console.WriteLine(ogrenci1[2]);

            /*Console.WriteLine(ogrenci1.numara);
            Console.WriteLine(ogrenci1.cinsiyet);*/

            Ogrenci ogrenci2 = new Ogrenci();
            Ogrenci ogrenci3 = new Ogrenci();
        }
        // Parametre almayan(() arası boş) ve geri dönüş değeri olmayan(void) metot
        public static void Selamla() // İmza
        {
            // Gövde
            Console.WriteLine("Hoşgeldiniz.");
        }

        // Parametre alan(() arası dolu olmalı) ve geri dönüş değeri olmayan(void) metot
        public static void Selamla2(string isim, int yas) // İmza
        {
            // Gövde
            Console.WriteLine($"Hoşgeldin {isim} yaşınız {yas}");
        }

        // Parametre almayan(() arası boş olmalı) ve geri dönüş değeri olan(int, string, bool vb.) metot
        public static int Selamla3() // İmza
        {
            int toplam = 21 + 8;
            return toplam;
        }

        // Parametre alan(() arası dolu olmalı) ve geri dönüş değeri olan(int, string, bool vb.) metot
        public static int Selamla4(int deger1, int deger2) // İmza
        {
            int toplam = deger1 + deger2;
            return toplam;
        }

    }
    class Ogrenci
    {
        public int yas, numara;
        public string isim, soyisim;
        public double boy, kilo;
        public bool cinsiyet;
        private int bakiye;
        private int deger;

        public int Bakiye
        {
            get
            {
                return bakiye * 2;
            }

            set
            {
                bakiye = value;
            }
        }

        public int Para { get; set; }

        public int Topla(int sayi1, int sayi2)
        {
            return sayi1 + sayi2;
        }

        public int this[int a]
        {
            get
            {
                return deger;
            }

            set
            {
                deger = value;
            }
        }
    }


}
