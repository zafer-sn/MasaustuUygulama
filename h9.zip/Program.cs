﻿namespace CokbicimlilikSoyutlama
{
    class A
    {
        public virtual void Hesap()
        {
            Console.WriteLine("A Hesaplanıyor");
        }
    }
    class B : A
    {

    }

    class C : B
    {
        public override void Hesap()
        {
            Console.WriteLine("C hesaplanıyor");
        }
    }
    class D : C
    {
        public override void Hesap()
        {
            Console.WriteLine("D hesaplanıyor");
        }
    }

    class E : D
    {

    }

    class Deneme
    {
        // private olursa olmaz
        public virtual void Ornek()
        {
            Console.WriteLine("deneme");
        }
    }

    class Test : Deneme
    {
        public override void Ornek()
        {

        }
        // Test metodu ezilmek zorunda değil
    }

    class Hayvan
    {
        public string Dolasim;
        public virtual string HucreselYapi { get; set; }
        public virtual void Hareket()
        {
            Console.WriteLine("Hayvan hareket ediyor");
            Console.WriteLine(HucreselYapi);
        }
    }
    class Kedi : Hayvan
    {
        public override string HucreselYapi { get; set; }
        public override void Hareket()
        {
            Console.WriteLine("Kedi hareket ediyor");
            Console.WriteLine(HucreselYapi);
        }
    }


    class Bitki
    {
        public int Boy { get; set; }
        public virtual void Fotosentez()
        {
            Console.WriteLine("Bitki Fotosentez yapıyor");
        }
    }

    class Gul : Bitki
    {
        public override void Fotosentez()
        {
            Console.WriteLine("Gul fotosentez yapıyor");
        }
    }

    class Sekil
    {
        public Sekil(int En, int Boy)
        {
            this.En = En;
            this.Boy = Boy;
        }
        public int En { get; set; }
        public int Boy { get; set; }
        public virtual int AlanHesapla()
        {
            return 0;
        }
    }
    class Ucgen : Sekil
    {
        public Ucgen(int En, int Boy) : base(En, Boy)
        {

        }
        public override int AlanHesapla()
        {
            return (En * Boy) / 2;
        }
    }
    class Dikdortgen : Sekil
    {
        public Dikdortgen(int En, int Boy) : base(En, Boy)
        {

        }
        public override int AlanHesapla()
        {
            return (En * Boy);
        }
    }

    class Kus
    {
        public void Kus_Hareketi()
        {
            Console.WriteLine("Kus hareket ediyor");
        }
    }

    class Papagan : Kus
    {
        public void Papagan_Hareketi()
        {
            Console.WriteLine("Papagan hareket ediyor");
        }
    }

    abstract class Okul
    {
        public void Zil()
        {
            Console.WriteLine("Zil çalıyor");
        }

        abstract public void Ders();
        abstract public int Ders_Sayisi { get; set; }

    }

    class Universite : Okul
    {
        public override int Ders_Sayisi { get; set; }

        public override void Ders()
        {
            Console.WriteLine("Ders işleniyor");
        }
    }

    internal class Program
    {

        static void Main(string[] args)
        {
            Bitki bitki1 = new Bitki();
            Gul gul1 = new Gul();
            bitki1.Fotosentez();
            gul1.Fotosentez();

            Hayvan hayvan1 = new Hayvan();
            hayvan1.HucreselYapi = "Hayvan hucresi";
            hayvan1.Hareket();
            Kedi kedi1 = new Kedi();
            kedi1.HucreselYapi = "Kedi hucresi";
            kedi1.Hareket();

            Sekil seki1 = new Sekil(3, 4);
            Console.WriteLine(seki1.AlanHesapla());
            Ucgen ucgen1 = new Ucgen(5, 6);
            Console.WriteLine(ucgen1.AlanHesapla());
            Dikdortgen dikdortgen1 = new Dikdortgen(4, 5);
            Console.WriteLine(dikdortgen1.AlanHesapla());

            A a1 = new A();
            a1.Hesap();
            B b1 = new B();
            b1.Hesap();
            C c1 = new C();
            c1.Hesap();
            D d1 = new D();
            d1.Hesap();
            Kus kus1 = new Kus();
            kus1.Kus_Hareketi();
            Kus papagan1 = new Papagan();
            Universite universite1 = new Universite();
            universite1.Ders();





        }
    }
}

