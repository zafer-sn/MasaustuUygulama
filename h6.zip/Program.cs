﻿namespace hafta6
{
    class Ogrenci
    {
        public int yas; // private int yas;
        public string Ad;
        public double Kilo { get; set; }
        public double Boy { get; set; }
        public int Hesapla(int yas, int y)
        {
            return yas;
        }

    }

    class Personel
    {
        public string Ad { get; set; }
        public int Yas { get; set; }
        public Personel(string Ad, int Yas)
        {
            // this.Ad = Ad;
            // Yas = this.Yas; // this.Yas = 22
        }

        public void X()
        {
            Console.WriteLine("Deneme");
        }
    }

    class Bitki
    {
        public Bitki()
        {
            Console.WriteLine("Boş ctor.");
        }

        public Bitki(int Yas)
        {
            Console.WriteLine("Tek parametreli ctor.");
        }
        public Bitki(string Ad)
        {
            Console.WriteLine("Tek parametre Ad");
        }
        public Bitki(string Ad, double Boy)
        {
            Console.WriteLine("Çift parametre Ad boy");
        }

        public Bitki(double Boy, string Ad)
        {
            Console.WriteLine("Çift parametre Boy Ad");
        }
    }

    class Kapi
    {
        private Kapi()
        {

        }

        public void X()
        {
            Kapi k1 = new Kapi();
        }
        // Singleton design pattern
    }

    class Hayvan
    {
        public Hayvan()
        {
            Console.WriteLine("Nesne oluşturuldu");
        }
        ~Hayvan()
        {
            Console.WriteLine("Nesne imha edildi");
        }
    }

    class Araba
    {
        public Araba()
        {
            Console.WriteLine("Normal constructor(yapıcı metot) çalıştı.");
        }

        static Araba()
        {
            Console.WriteLine("Static constructor(yapıcı metot) çalıştı.");
        }
    }


    internal class Program
    {

        static void Main(string[] args)
        {
            Ogrenci ogrenci1 = new Ogrenci();
            ogrenci1.yas = 20;
            // Console.WriteLine(ogrenci1.Hesapla(30, 5));
            Personel personel1 = new Personel("Sefkan", 22);
            personel1.Yas = 55;
            // Console.WriteLine(personel1.Ad);
            // Console.WriteLine(personel1.Yas);
            // Bitki bitki1 = new Bitki();
            // Bitki bitki2 = new Bitki(12);
            Bitki bitki3 = new Bitki("Lale", 1.2);
            // Bitki bitki4 = new Bitki(1.5, "Gül");
            // Kapi kapi1 = new Kapi();
            new Ogrenci();
            Nesne_Olustur();
            GC.Collect();
            // Console.ReadLine();

            Araba civic = new Araba();
            Araba corolla = new Araba();
            Araba mx5 = new Araba();
            Araba impreza = new Araba();
            /*Console.WriteLine(Math.Pow(5, 4));
            Console.WriteLine(Math.Pow(2, 6));
            Console.WriteLine(Math.Pow(1, 110));
            Console.WriteLine(Math.Pow(-1, 110));
            Console.WriteLine(Math.Pow(-1, 109));*/
            double deger1 = hesapla(1, 1);
            Console.WriteLine(deger1);
            double deger2 = hesapla(2, 3);
            Console.WriteLine(deger2);
        }

        public static double hesapla(double x, double y)
        {
            return 5 * Math.Pow(x, 2) + 3 * Math.Pow(y, 11) + 9;
        }


        public static void Nesne_Olustur()
        {
            Hayvan kedi = new Hayvan();
        }
    }
}
