﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUygulama
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var deger1 = Convert.ToDouble(maskedTextBox1.Text);
            var deger2 = Convert.ToDouble(maskedTextBox2.Text);
            var sonuc = 0.0;
            if (comboBox1.Text == "+")
            {
                sonuc = deger1 + deger2;
            }
            else if (comboBox1.Text == "-")
            {
                sonuc = deger1 - deger2;
            }
            else if (comboBox1.Text == "*")
            {
                sonuc = deger1 * deger2;
            }
            else
            {
                sonuc = deger1 / deger2;
            }
            MessageBox.Show($"Girdiğiniz 1. değer: {deger1}\nGirdiğiniz 2. değer: {deger2}\nSeçtiğiniz işlem: {comboBox1.Text}\nBuna göre sonuç = {deger1} {comboBox1.Text} {deger2} = {sonuc}");

        }
    }
}
