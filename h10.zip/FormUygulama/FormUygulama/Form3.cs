﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUygulama
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var vize_notu = Convert.ToDouble(textBox1.Text);
                var final_notu = Convert.ToDouble(textBox2.Text);
                var ortalama = vize_notu * 0.4 + final_notu * 0.6;
                if (vize_notu >= 0 && vize_notu <= 100 && final_notu >= 0 && final_notu <= 100)
                {
                    if (ortalama >= 45)
                    {
                        MessageBox.Show($"Ortalamanız: {ortalama}\nDurum:Geçti");
                    }
                    else
                    {
                        MessageBox.Show($"Ortalamanız: {ortalama}\nDurum:Kaldı");

                    }
                }
                else
                {
                    MessageBox.Show($"Vize ve final notları [0-100] aralığında olmalıdır!");
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Lütfen sayısal değer giriniz!");
            }

        }
    }
}
