namespace FormUygulama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = $"Girdi�iniz 1. de�er: {textBox1.Text} \nGirdi�iniz 2. de�er: {textBox2.Text}";
        }
    }
}
