using Hafta13.Entities;
using System.Linq.Expressions;

namespace Hafta13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            KayitlariGoster kg = new KayitlariGoster();
            kg.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            KullaniciGuncelle kulgun = new KullaniciGuncelle();
            kulgun.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SilinecekKullanici silinkul = new SilinecekKullanici();
            silinkul.Show();
        }
    }
}
