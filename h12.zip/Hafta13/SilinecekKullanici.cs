﻿using Hafta13.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta13
{
    public partial class SilinecekKullanici : Form
    {
        public SilinecekKullanici()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UygulamaDbContext udbc = new UygulamaDbContext();
            var silinecek_kullanici = udbc.Kullanicilar.FirstOrDefault(kk => kk.Adi == textBox1.Text && kk.Parola == textBox2.Text);
            udbc.Remove(silinecek_kullanici);
            udbc.SaveChanges();
        }
    }
}
