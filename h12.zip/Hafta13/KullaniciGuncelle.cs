﻿using Hafta13.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta13
{
    public partial class KullaniciGuncelle : Form
    {
        public KullaniciGuncelle()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UygulamaDbContext udbc = new UygulamaDbContext();
            var guncellenecek_kullanici = udbc.Kullanicilar.FirstOrDefault(k => k.Adi == textBox1.Text && k.Parola == textBox2.Text && k.Telefon == Convert.ToDouble(textBox3.Text) && k.TC == Convert.ToDouble(textBox4.Text));
            guncellenecek_kullanici.Adi = textBox5.Text;
            guncellenecek_kullanici.Parola = textBox6.Text;
            guncellenecek_kullanici.Telefon = Convert.ToDouble(textBox7.Text);
            guncellenecek_kullanici.TC = Convert.ToDouble(textBox8.Text);
            MessageBox.Show("Güncelleme başarılı");
            udbc.SaveChanges();
        }
    }
}
