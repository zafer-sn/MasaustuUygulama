﻿using Hafta13.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta13
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UygulamaDbContext udbc = new UygulamaDbContext();
            Kullanici k1 = new Kullanici();
            k1.Adi = textBox1.Text;
            k1.Parola = textBox2.Text;
            k1.Telefon = Convert.ToDouble(maskedTextBox1.Text);
            k1.TC = Convert.ToDouble(maskedTextBox2.Text);
            udbc.Add(k1);
            udbc.SaveChanges();
            MessageBox.Show("Başarılı bir şekilde kaydedildi");
            textBox1.Text = "";
            textBox2.Text = "";
            maskedTextBox1.Text = "";
            maskedTextBox2.Text = "";

        }
    }
}
