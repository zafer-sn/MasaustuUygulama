﻿using Hafta13.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta13
{
    public partial class Form2 : Form
    {
        public int GirisSayisi { get; set; } = 3;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UygulamaDbContext udbc = new UygulamaDbContext();
            var kullanici = udbc.Kullanicilar.FirstOrDefault(kk => kk.Adi == textBox1.Text && kk.Parola == textBox2.Text);
            if (kullanici == null)
            {
                MessageBox.Show("Kullanıcı bulunamadı!", "UYARI", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Giriş başarılı");
            }
        }
    }
}
