﻿internal class Program
{
    static int varsayilan_deger;
    private static void Main(string[] args)
    {
        #region Değişken tanımlama yöntemleri
        int birinci_sayinin_degeri = 15; //snake_case kullanımı
        int ikinci_sayinin_degeri = 25;

        int ucuncuSayininDegeri = 50; //camelCase kullanımı
        int dorduncuSayininDegeri = 100;

        int BesinciSayininDegeri = 150;//PascalCase kullanımı
        int AltinciSayininDegeri = 250;
        #endregion
        #region Built-in değer atama
        int @for = 5;
        // Console.WriteLine(@for);
        #endregion
        #region Değişken tanımlama
        int sayi1 = 11;
        double sayi2 = 11.7;
        float sayi3 = 21.7f;
        decimal sayi4 = 5.4m;

        string isim = "Zafer";
        char karakter = 'a';
        bool giris_yapildimi = false;

        int deger1;
        deger1 = 25;
        #endregion
        #region Değişken Kuralları
        int sayisal_deger = 25;
        sayisal_deger = 55;
        sayisal_deger = 111;
        sayisal_deger = 100;
        // Console.WriteLine(sayisal_deger);
        #endregion
        #region string kullanımı
        string ad = "test";
        string soyad = "deneme";
        #endregion
        #region char kullanımı
        char a_karakteri = 'a';
        char yildiz_karakteri = '*';
        #endregion
        #region mantıksal değerler
        bool test_edildimi = true;
        bool donus_yapildimi = false;
        #endregion
        #region Sayısal değerler
        byte byte_deger = 255;
        int yas = 25;
        float ondalikli_sayi_1 = 1.65f; // 1.65F
        double ondalikli_sayi_2 = 1.65; // 1.65d, 1.65D
        decimal ondalikli_sayi_3 = 1.65m; // 1.65M
        #endregion
        #region Tuple kullanımı
        (int sayisal_deger1, string sayisal_deger2) tuple_degeri = (11, "Zafer");
        // tuple_degeri.sayisal_deger1 = 25;
        // tuple_degeri.sayisal_deger2 = 55;
        // Console.WriteLine(tuple_degeri);
        #endregion
        #region Console.WriteLine kullanımı
        int tamsayi_degeri = 25;
        double ondalikli_sayi_degeri = 25.7;
        string isim_degiskeni = "Zafer";
        // Console.WriteLine("Sizin tamsayı değeriniz:" + tamsayi_degeri + "Sizin ondalıklı sayı değeriniz:" + ondalikli_sayi_degeri);
        // Console.WriteLine($"Sizin adınız: {isim_degiskeni} Sizin tamsayı değeriniz:{tamsayi_degeri}, enenme test wakhgbwq, sizin ondalıklı sayı değeriniz:{ondalikli_sayi_degeri}");
        #endregion
        #region Literals kullanım
        int buyuk_sayi = 1_000_000_000; // 1000000000
        // Console.WriteLine(buyuk_sayi);
        #endregion
        #region varsayılan değer atama
        int varsayilan_deger2=11;
        bool varsayilan_deger3 = default;
        int varsayilan_deger4 = default;
        char varsayilan_deger5 = default;
        string varsayilan_deger6 = default;       

        /*Console.WriteLine(varsayilan_deger3);
        Console.WriteLine(varsayilan_deger4);
        Console.WriteLine(varsayilan_deger5);
        Console.WriteLine(varsayilan_deger6);*/

        #endregion
        #region scope kavramı
        {
            int scope_degeri = 15;
            {
                scope_degeri = 55;
            }
        }
        {
            int scope_degeri = 25;
        }
        #endregion
        #region değişmeyenler
        const int yas1 = 25;
        const string deger = "deneme";
        const double pi_sayisi = 3.14;
        //Console.WriteLine(pi_sayisi);
        #endregion
        #region atama varyasyonları
        int atama1 = 5;
        int atama2 = 15;
        int ornek1 = 15, ornek2 = 25;
        #endregion
        #region object tipi
        object isim2 = "Zafer";
        object sayi_degeri = 25;
        object sayi_degeri2 = 35;
        object test_varmi = true;
        object kontrol_varmi = false;
        isim2 = "Test";
        int test1 = 15;
        int test2 = 25;
        // Console.WriteLine((int)sayi_degeri + (int)sayi_degeri2);
        #endregion
        #region var yapisi
        var deger11 = 15;
        var deger12 = 3.75;
        var deger13 = "test";
        var deger14 = true;
        deger14 = false;
        // Console.WriteLine(deger14);
        #endregion
        #region dynamic yapisi
        dynamic dinamik_sayi = 25;
        dynamic dinamik_metin = "Zafer";
        System.Console.WriteLine(dinamik_metin.GetType());
        dinamik_metin = 25;
        Console.WriteLine(dinamik_metin.GetType());
        dynamic dinamik_mantiksal = true;
        Console.WriteLine("test");
        #endregion        
    }
}