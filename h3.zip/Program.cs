﻿using System.Runtime.InteropServices;

internal class Program
{
    private static void Main(string[] args)
    {
        #region Metinsel ifadelerin diğer türlere dönüşümü
        string deger_1 = "2000";
        // Console.WriteLine(deger_1.GetType());
        int deger_1_int = int.Parse(deger_1);
        // Console.WriteLine(deger_1_int.GetType());

        string deger_2 = "trUE";
        bool deger_2_bool = Convert.ToBoolean(deger_2);
        // Console.WriteLine(deger_2_bool.GetType());

        string deger_3 = "128,5";
        float deger_3_f = Convert.ToSingle(deger_3);
        // Console.WriteLine(deger_3_f);
        #endregion
        #region Sayısal ifadelerin kendi arasında dönüşümü
        short deger_4 = 255;
        int deger_4_i = deger_4;
        // Console.WriteLine(deger_4_i.GetType());

        int deger_5 = 2500;
        short deger_5_s = (short)deger_5;
        // Console.WriteLine(deger_5_s);

        int deger_6 = 125;
        byte deger_6_b = (byte)deger_6;
        #endregion
        #region checked ve unchecked
        short deger_7 = 5445;
        checked
        {
            // byte deger_7_b = (byte)deger_7;
        }
        unchecked
        {

        }
        #endregion
        #region Mantıksal türlerin dönüşümü
        bool deger_8 = false;
        int deger_8_i = Convert.ToInt32(deger_8);
        // Console.WriteLine(deger_8_i);

        int deger_9 = 55;
        bool deger_9_b = Convert.ToBoolean(deger_9);
        // Console.WriteLine(deger_9_b);
        #endregion
        #region Karakter türlerin sayısal türlere dönüşümü
        char deger_10 = ' ';
        int deger_10_i = Convert.ToInt32(deger_10);
        // Console.WriteLine(deger_10_i);

        int deger_11 = 67;
        char deger_11_c = Convert.ToChar(deger_11);
        // Console.WriteLine(deger_11_c);
        #endregion
        #region Console.ReadLine() kullanımı
        /*Console.WriteLine("Lütfen 1. sayiyi giriniz..:");
        string deger_12 = Console.ReadLine();
        int deger_12_i = Convert.ToInt32(deger_12);
        Console.WriteLine("Lütfen 2. sayiyi giriniz..:");
        string deger_13 = Console.ReadLine();
        int deger_13_i = Convert.ToInt32(deger_13);
        Console.WriteLine(deger_12_i + deger_13_i);*/
        #endregion
        #region Aritmetiksel operatörler
        int deger_14 = 5;
        int deger_15 = 3;
        /*Console.WriteLine(deger_14 + deger_15);
        Console.WriteLine(11 - 5);
        Console.WriteLine(3 * 7);
        Console.WriteLine(50 / 3);
        Console.WriteLine(11 % 7);
        int deger_16 = Convert.ToInt32(Console.ReadLine());
        int deger_17 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(deger_16 + deger_17);*/
        #endregion
        #region Karşılaştırma operatörü
        /*Console.WriteLine(5 > 7); // false
        Console.WriteLine(11 > 2); // true
        Console.WriteLine(5 > 5); // false
        Console.WriteLine(3 <= 3); // true
        Console.WriteLine(3 != 11); // true
        Console.WriteLine(7 == 7); // true*/
        #endregion
        #region Mantıksal operatörler
        // && operatörü sonucunda true dönebilmesi için her şartın sağlanması gerekir
        /*Console.WriteLine(5 > 7 && 11 > 2);
        Console.WriteLine(true && true);
        Console.WriteLine(5 != 5 && 7 > 2 && 11 == 11);*/

        /*Console.WriteLine(5 > 7 || 11 > 2); // true
        Console.WriteLine(false || false); // false
        Console.WriteLine(2 < -5 || 4 > 25); //false*/
        // Console.WriteLine(5 > 7 ^ 11 > 2); // true
        // Console.WriteLine(25 > -5 ^ 11 > 1); // false
        #endregion
        #region İşlem önceliği
        bool deger_16 = true;
        // Console.WriteLine(!deger_16);
        // Console.WriteLine((25 + 11) * 2 - (11 + 3) / 3); // (36)*2-(14)/3 -> 72-4 -> 68
        #endregion
        #region artırma operatörleri ++ -> 1 artırm -- -> 1 azaltma
        int i = 4; // i = 4
        int i2 = i++; // i2 = 4, i = 5
        int i3 = ++i; // i3 = 6, i = 6
        i++; // i = 7
        int i4 = i3++; // i4 = 6, i3 = 7
        int i5 = ++i2; // i5 = 5, i2 = 5
        i5++; // i5 = 6
        // i = 7, i2 = 5, i3 = 7, i4 = 6, i5 = 6
        // Console.WriteLine($"{i}, {i2}, {i3}, {i4}, {i5}");
        #endregion
        #region üzerine ekleme yığma operatörleri
        int deger_17 = 25;
        deger_17 = deger_17 + 5;
        deger_17 = deger_17 * 2;
        // Console.WriteLine(deger_17);
        int deger_18 = 5;
        deger_18 += 7; // deger_18 = deger_18 + 5;
        deger_18 *= 3; // deger_18 = deger_18 * 3;
        // Console.WriteLine(deger_18);
        #endregion
        #region sizeof
        // Console.WriteLine(sizeof(double));
        #endregion
        #region typeof
        // string deger_20 = "Zafer";
        Type t = typeof(string);
        // Console.WriteLine(t.IsValueType);
        #endregion
        #region is ve is null
        string deger_21 = " ";
        //Console.WriteLine(deger_21 is null);
        #endregion
        #region as operatörü
        object deger_22 = 25;
        string deger_22_s = deger_22 as string;
        #endregion
        #region değer tipli değişkeni null yapma
        int? deger_23 = null;
        #endregion
        #region ?? operatörü
        string deger_25 = null;
        Console.WriteLine(deger_25 ?? "TEST");
        Console.WriteLine(deger_25);
        #endregion
        #region ??= operatörü
        string deger_26 = null;
        Console.WriteLine(deger_26 ??= "TEST");
        Console.WriteLine(deger_26);
        #endregion
    }
}