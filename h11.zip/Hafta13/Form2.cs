﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hafta13
{
    public partial class Form2 : Form
    {
        public int GirisSayisi { get; set; } = 3;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "admin" && textBox2.Text == "admin")
            {
                MessageBox.Show("Giriş Başarılı");
            }
            else
            {
                GirisSayisi -= 1;
                if (GirisSayisi == 0)
                {
                    Application.Exit();
                }
                MessageBox.Show($"Giriş başarısız!\nKalan deneme hakkınız: {GirisSayisi}");
            }
        }
    }
}
